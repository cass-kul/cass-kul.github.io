#ifndef SECRET_H_INC
#define SECRET_H_INC

#define SECRET_PWD      "m}f" // Obfuscated password
#define OBFUSCATE       "XOR"
#define FR_SECRET       5

#endif
